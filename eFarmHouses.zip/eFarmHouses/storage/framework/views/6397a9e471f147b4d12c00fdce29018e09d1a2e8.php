
<?php $__env->startSection('my_contain'); ?>
<?php echo $__env->yieldSection(); ?>

<div class="main-footer">
        <div class="container">
            <div class="row">
                                                                                <div class="col-lg-3 col-md-6">
                            <div class="nav-footer">
                                <div class="title">
                                    NEED HELP?
                                </div>
                                <div class="context">
                                    <div class="contact">
        <div class="c-title">
            Call Us
        </div>
        <div class="sub">
            + 00 222 44 5678
        </div>
    </div>
    <div class="contact">
        <div class="c-title">
            Email for Us
        </div>
        <div class="sub">
            hello@yoursite.com
        </div>
    </div>
    <div class="contact">
        <div class="c-title">
            Follow Us
        </div>
        <div class="sub">
            <a href="#">
                <img src="https://travelhotel.wpengine.com/wp-content/uploads/2018/12/ico_facebook_footer.png">
            </a>
            <a href="#">
                <img src="https://travelhotel.wpengine.com/wp-content/uploads/2018/12/ico_twitter_footer.png">
            </a>
            <a href="#">
                <img src="https://travelhotel.wpengine.com/wp-content/uploads/2018/12/ico_instagram_footer.png">
            </a>
        </div>
    </div>
                                </div>
                            </div>
                        </div>
                                            <div class="col-lg-3 col-md-6">
                            <div class="nav-footer">
                                <div class="title">
                                    COMPANY
                                </div>
                                <div class="context">
                                    <ul>
    <li><a href="#">About Us</a></li>
    <li><a href="#">Community Blog</a></li>
    <li><a href="#">Rewards</a></li>
    <li><a href="#">Work with Us</a></li>
    <li><a href="#">Meet the Team</a></li>
</ul>
                                </div>
                            </div>
                        </div>
                                            <div class="col-lg-3 col-md-6">
                            <div class="nav-footer">
                                <div class="title">
                                    SUPPORT
                                </div>
                                <div class="context">
                                    <ul>
    <li><a href="#">Account</a></li>
    <li><a href="#">Legal</a></li>
    <li><a href="#">Contact</a></li>
    <li><a href="#">Affiliate Program</a></li>
    <li><a href="#">Privacy Policy</a></li>
</ul>
                                </div>
                            </div>
                        </div>
                                            <div class="col-lg-3 col-md-6">
                            <div class="nav-footer">
                                <div class="title">
                                    SETTINGS
                                </div>
                                <div class="context">
                                    <ul>
<li><a href="#">Setting 1</a></li>
<li><a href="#">Setting 2</a></li>
</ul>
                                </div>
                            </div>
                        </div>
                                                </div>
        </div>
    </div>
    <div class="copy-right">
        <div class="container context">
            <div class="row">
                <div class="col-md-12">
                    <p>Copyright © 2020 by eFarmhouses</p>
                    <div class="f-visa">
                        <p>eFarmhouses</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content relative">
            <div class="modal-header">
                <h4 class="modal-title">Log In</h4>
                <span class="c-pointer" data-dismiss="modal" aria-label="Close">
                    <i class="input-icon field-icon fa">
                        <img src="http://efarmhouses.pk/images/ico_close.svg" alt="close">
                    </i>
                </span>
            </div>
            <div class="modal-body relative">
                <form class="bravo-form-login" method="POST" action="http://efarmhouses.pk/en/login">
    <input type="hidden" name="_token" value="gth46RLoZbmvS515h76Q3ZbsHwYAKq23ExcKCG4e">    <div class="form-group">
        <input type="text" class="form-control" name="email" autocomplete="off" placeholder="Email address">
        <i class="input-icon fa fa-envelope-o"></i>
        <span class="invalid-feedback error error-email"></span>
    </div>
    <div class="form-group">
        <input type="password" class="form-control" name="password" autocomplete="off" placeholder="Password">
        <i class="input-icon fa fa-lock"></i>
        <span class="invalid-feedback error error-password"></span>
    </div>
    <div class="form-group">
        <div class="d-flex justify-content-between">
            <label for="remember-me" class="mb0">
                <input type="checkbox" name="remember" id="remember-me" value="1"> Remember me <span class="checkmark fcheckbox"></span>
            </label>
            <a href="http://efarmhouses.pk/en/password/reset">Forgot Password?</a>
        </div>
    </div>
        <div class="error message-error invalid-feedback"></div>
    <div class="form-group">
        <button class="btn btn-primary form-submit" type="submit">
            Login
            <span class="spinner-grow spinner-grow-sm icon-loading" role="status" aria-hidden="true"></span>
        </button>
    </div>
            <div class="advanced">
            <p class="text-center f14 c-grey">or continue with</p>
            <div class="row">
                                    <div class="col-xs-12 col-sm-4">
                        <a href="http://efarmhouses.pk/social-login/facebook" class="btn btn_login_fb_link" data-channel="facebook">
                            <i class="input-icon fa fa-facebook"></i>
                            Facebook
                        </a>
                    </div>
                                                            </div>
        </div>
        <div class="c-grey font-medium f14 text-center"> Do not have an account? <a href="" data-target="#register" data-toggle="modal">Sign Up</a>
    </div>
</form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content relative">
            <div class="modal-header">
                <h4 class="modal-title">Sign Up</h4>
                <span class="c-pointer" data-dismiss="modal" aria-label="Close">
                    <i class="input-icon field-icon fa">
                        <img src="http://efarmhouses.pk/images/ico_close.svg" alt="close">
                    </i>
                </span>
            </div>
            <div class="modal-body">
                <script>
    function validateYakeen() {

        var nin = $("#nin").val();
        var dob = $("#dob").val();

        $.ajax({
            url: 'https://yakeen-lite-qa-api-beta.dev-apps.elm.sa/yakeen-lite/api/v1/saudi-info/' + nin + '?birthDate=' + dob,
            beforeSend: function (xhr) {
                xhr.setRequestHeader("APP-ID", "d3dba86f")
                xhr.setRequestHeader("APP-KEY", "fd9df49317098050227cf3201fdd4133")
            },
            success: function(data, textStatus, xhr) {
                if(data.id!=null){
                    alert("verifiued");
                    document.getElementById('registerButton').type = 'submit';
                    $("#registerButton").click();
                }
            },
            complete: function(xhr, textStatus) {
                if(textStatus==400){
                    alert("nope");
                    $(".invalid-feedback.error.nin-error").append('Yaqeen could not verify the user data, sorry you cannot proceed');
                }
            }


        });
    }

</script>

<form class="form bravo-form-register" method="post">
    <input type="hidden" name="_token" value="gth46RLoZbmvS515h76Q3ZbsHwYAKq23ExcKCG4e">
    <div class="row">
        <div class="col-lg-6 col-md-12">
            <div class="form-group">
                <input value="1130173675" name="nin" type="text" class="form-control" id="nin" placeholder="NIN">
                <i class="input-icon field-icon fa"><img src="http://efarmhouses.pk/images/ico_fullname_signup.svg"></i>

            </div>
        </div>
        <div class="col-lg-6 col-md-12">
            <div class="form-group">
                <input value="20-02-1413" type="text" name="dob" class="form-control" id="dob" autocomplete="off" placeholder="DOB e.g. mm-dd-yyy">
                <i class="input-icon field-icon fa"><img src="http://efarmhouses.pk/images/ico_fullname_signup.svg"></i>
                <span class="invalid-feedback error error-dob"></span>
            </div>
        </div>

    </div>
    <div class="col-lg-12 col-md-12">
        <span class="invalid-feedback error error-nin"></span>
    </div>

    <div class="row">
        <div class="col-lg-6 col-md-12">
            <div class="form-group">
                <input type="text" class="form-control" name="first_name" autocomplete="off" placeholder="First Name">
                <i class="input-icon field-icon fa"><img src="http://efarmhouses.pk/images/ico_fullname_signup.svg"></i>
                <span class="invalid-feedback error error-first_name"></span>
            </div>
        </div>
        <div class="col-lg-6 col-md-12">
            <div class="form-group">
                <input type="text" class="form-control" name="last_name" autocomplete="off" placeholder="Last Name">
                <i class="input-icon field-icon fa"><img src="http://efarmhouses.pk/images/ico_fullname_signup.svg"></i>
                <span class="invalid-feedback error error-last_name"></span>
            </div>
        </div>
    </div>
    <div class="form-group">
        <input type="email" class="form-control" name="email" autocomplete="off" placeholder="Email *">
        <i class="input-icon field-icon fa"><img src="http://efarmhouses.pk/images/ico_email_login_form.svg"></i>
        <span class="invalid-feedback error error-email"></span>
    </div>
    <div class="form-group">
        <input type="password" class="form-control" name="password" autocomplete="off" placeholder="Password *">
        <i class="input-icon field-icon fa"><img src="http://efarmhouses.pk/images/ico_pass_login_form.svg"></i>
        <span class="invalid-feedback error error-password"></span>
    </div>
    <div class="form-group">
        <label for="term">
            <input id="term" type="checkbox" name="term" class="mr5">
            I have read and accept the <a href="" target="_blank">Terms and Privacy Policy</a>
            <span class="checkmark fcheckbox"></span>
        </label>
        <div><span class="invalid-feedback error error-term"></span></div>
    </div>
        <div class="error message-error invalid-feedback"></div>
    <div class="form-group">
        <button type="submit" id="registerButton" class="btn btn-primary form-submit">
            Sign Up
            <span class="spinner-grow spinner-grow-sm icon-loading" role="status" aria-hidden="true"></span>
        </button>
    </div>
            <div class="advanced">
            <p class="text-center f14 c-grey">or continue with</p>
            <div class="row">
                                    <div class="col-xs-12 col-sm-4">
                        <a href="http://efarmhouses.pk/social-login/facebook" class="btn btn_login_fb_link" data-channel="facebook">
                            <i class="input-icon fa fa-facebook"></i>
                            Facebook
                        </a>
                    </div>
                                                            </div>
        </div>
        <div class="c-grey f14 text-center">
        Already have an account?
        <a href="#" data-target="#login" data-toggle="modal">Log In</a>
    </div>
</form>


<script>


</script>            </div>
        </div>
    </div>
</div><link rel="stylesheet" href="css/flag-icon.min.css">


<script src="js/intersection-observer.js"></script>
<script async="" src="js/lazyload.min.js"></script>
<script>
    // Set the options to make LazyLoad self-initialize
    window.lazyLoadOptions = {
        elements_selector: ".lazy",
        // ... more custom settings?
    };

    // Listen to the initialization event and get the instance of LazyLoad
    window.addEventListener('LazyLoad::Initialized', function (event) {
        window.lazyLoadInstance = event.detail.instance;
    }, false);


</script>
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/vue.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/moment.min.js"></script>
<script type="text/javascript" src="js/daterangepicker.min.js"></script>
<script src="js/functions.js"></script>
<script src="js/home.js"></script>




    </div>
    


<div class="daterangepicker ltr auto-apply show-calendar opensright"><div class="ranges"></div><div class="drp-calendar left"><div class="calendar-table"></div><div class="calendar-time" style="display: none;"></div></div><div class="drp-calendar right"><div class="calendar-table"></div><div class="calendar-time" style="display: none;"></div></div><div class="drp-buttons"><span class="drp-selected"></span><button class="cancelBtn btn btn-sm btn-default" type="button">Cancel</button><button class="applyBtn btn btn-sm btn-primary" disabled="disabled" type="button">Apply</button> </div></div></body></html><?php /**PATH C:\Users\CCS\Desktop\laravel\eFarmHouses\resources\views/main_footer_layout.blade.php ENDPATH**/ ?>