<html lang="en" class=""><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="gth46RLoZbmvS515h76Q3ZbsHwYAKq23ExcKCG4e">
                                    <link rel="icon" type="image/png" href="http://efarmhouses.pk/uploads/demo/general/favicon.png">
            
    <title>Home Page - eFarmhouses</title>
    <meta name="description" content="">
    
    <meta property="og:url" content="http://efarmhouses.pk">
    <meta property="og:type" content="article">
    <meta property="og:title" content="Home Page">
    <meta property="og:description" content="">
    <meta property="og:image" content="">
    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Home Page">
    <meta name="twitter:description" content="">
    <meta name="twitter:image" content="">
    <link rel="canonical" href="http://efarmhouses.pk">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/ionicons.min.css" rel="stylesheet">
    <link href="css/icofont.min.css" rel="stylesheet">
    <link href="css/app.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/daterangepicker.css">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link rel="stylesheet" id="google-font-css-css" href="https://fonts.googleapis.com/css?family=Poppins%3A400%2C500%2C600" type="text/css" media="all">
    <script>
        var bookingCore = {
            url:'http://efarmhouses.pk/en',
            booking_decimals:0,
            thousand_separator:'.',
            decimal_separator:',',
            currency_position:'left',
            currency_symbol:'?',
            date_format:'MM/DD/YYYY',
            map_provider:'gmap',
            map_gmap_key:'',
            routes:{
                login:'http://efarmhouses.pk/en/login',
                register:'http://efarmhouses.pk/en/register',
            }
        };
    </script>
    <!-- Styles -->
        
    <style id="custom-css">
    body{
            }
    a,
    .bravo-news .btn-readmore,
    .bravo_wrap .bravo_header .content .header-left .bravo-menu ul li:hover > a,
    .bravo_wrap .bravo_search_tour .bravo_form_search .bravo_form .field-icon,
    .bravo_wrap .bravo_search_tour .bravo_form_search .bravo_form .render,
    .bravo_wrap .bravo_search_tour .bravo_form_search .bravo_form .field-detination #dropdown-destination .form-control,
    .bravo_wrap .bravo_search_tour .bravo_filter .g-filter-item .item-content .btn-apply-price-range,
    .bravo_wrap .bravo_search_tour .bravo_filter .g-filter-item .item-content .btn-more-item,
    .input-number-group i,
    .bravo_wrap .page-template-content .bravo-form-search-tour .bravo_form_search_tour .field-icon,
    .bravo_wrap .page-template-content .bravo-form-search-tour .bravo_form_search_tour .field-detination #dropdown-destination .form-control,
    .bravo_wrap .page-template-content .bravo-form-search-tour .bravo_form_search_tour .render
    {
        color:#5191FA
    }
    .bravo-pagination ul li.active a, .bravo-pagination ul li.active span
    {
        color:#5191FA!important;
    }
    .bravo-news .widget_category ul li span,
    .bravo_wrap .bravo_search_tour .bravo_form_search .bravo_form .g-button-submit button,
    .bravo_wrap .bravo_search_tour .bravo_filter .filter-title:before,
    .bravo_wrap .bravo_search_tour .bravo_filter .g-filter-item .item-content .bravo-filter-price .irs--flat .irs-bar,
    .bravo_wrap .bravo_search_tour .bravo_filter .g-filter-item .item-content .bravo-filter-price .irs--flat .irs-from, .bravo_wrap .bravo_search_tour .bravo_filter .g-filter-item .item-content .bravo-filter-price .irs--flat .irs-to, .bravo_wrap .bravo_search_tour .bravo_filter .g-filter-item .item-content .bravo-filter-price .irs--flat .irs-single,
    .bravo_wrap .bravo_search_tour .bravo_filter .g-filter-item .item-content .bravo-filter-price .irs--flat .irs-handle>i:first-child,
    .bravo-news .header .cate ul li,
    .bravo_wrap .page-template-content .bravo-form-search-tour .bravo_form_search_tour .g-button-submit button,
    .bravo_wrap .page-template-content .bravo-list-locations .list-item .destination-item .image .content .desc
    {
        background: #5191FA;
    }
    .bravo-pagination ul li.active a, .bravo-pagination ul li.active span
    {
        border-color:#5191FA!important;
    }
    .bravo_wrap .bravo_search_tour .bravo_filter .g-filter-item .item-content .bravo-filter-price .irs--flat .irs-from:before, .bravo_wrap .bravo_search_tour .bravo_filter .g-filter-item .item-content .bravo-filter-price .irs--flat .irs-to:before, .bravo_wrap .bravo_search_tour .bravo_filter .g-filter-item .item-content .bravo-filter-price .irs--flat .irs-single:before,
    .bravo-reviews .review-form .form-wrapper,
    .bravo_wrap .bravo_detail_tour .bravo_content .bravo_tour_book
    {
        border-top-color:#5191FA;
    }

    .bravo_wrap .bravo_footer .main-footer .nav-footer .context .contact{
        border-left-color:#5191FA;
    }

    
</style>
    <link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/space.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/ion.rangeSlider.min.css">
    
</head>
<body class="" cz-shortcut-listen="true">
    
    <div class="bravo_wrap">

        <div class="bravo_topbar">
    <div class="container">
        <div class="content">
            <div class="topbar-left">

                <div class="socials">
    <a href="#"><i class="fa fa-facebook"></i></a>
    <a href="#"><i class="fa fa-linkedin"></i></a>
    <a href="#"><i class="fa fa-google-plus"></i></a>
</div>
<span class="line"></span>
<a href="mailto:contact@bookingcore.com">contact@bookingcore.com</a>


            </div>
            <div class="topbar-right">
                <ul class="topbar-items">
                    <li class="dropdown">
                                    <a href="#" data-toggle="dropdown" class="is_login">
                                            <span class="flag-icon flag-icon-gb"></span>
                                        English
                    <i class="fa fa-angle-down"></i>
                </a>
                            <ul class="dropdown-menu text-left">
                                                </ul>
    </li>
                                            <li class="login-item">
                            <a href="#login" data-toggle="modal" data-target="#login" class="login">Login</a>
                        </li>
                        <li class="signup-item">
                            <a href="#register" data-toggle="modal" data-target="#register" class="signup">Sign Up</a>
                        </li>
                                    </ul>
            </div>
        </div>
    </div>
</div>
        <div class="bravo_header">
    <div class="container">
        <div class="content">
            <div class="header-left">
                <a href="http://efarmhouses.pk/en" class="bravo-logo">
                                                                    <img src="http://efarmhouses.pk/uploads/0000/1/2020/09/28/whatsapp-image-2020-09-03-at-94958-am-copy.jpeg" alt="eFarmhouses">
                                    </a>
                <div class="bravo-menu">
                    <ul class="main-menu menu-generated"><li class=""><a target="" href="/">Home <i class="fa fa-angle-down"></i></a><ul class="children-menu menu-dropdown"><li class=" "><a target="" href="#">Home Tour</a></li><li class=" "><a target="" href="#">Home Space</a></li></ul></li><li class=" "><a target="" href="allFarmHouses.html">Farmhouses</a></li><li class=""><a target="" href="#">News <i class="fa fa-angle-down"></i></a><ul class="children-menu menu-dropdown"><li class=""><a target="" href="#">News List</a></li><li class=""><a target="" href="#">News Detail</a></li></ul></li><li class=""><a target="" href="contact.html">Contact</a></li></ul>                </div>
            </div>
            <div class="header-right">
                                <button class="bravo-more-menu">
                    <i class="fa fa-bars"></i>
                </button>
            </div>
        </div>
    </div>
    <div class="bravo-menu-mobile">
        <div class="user-profile">
            <div class="b-close"><i class="icofont-scroll-left"></i></div>
            <div class="avatar"></div>
            <ul>
                                    <li>
                        <a href="#login" data-toggle="modal" data-target="#login" class="login">Login</a>
                    </li>
                    <li>
                        <a href="#register" data-toggle="modal" data-target="#register" class="signup">Sign Up</a>
                    </li>
                            </ul>
            <ul class="multi-lang">
                <li class="dropdown">
                                    <a href="#" data-toggle="dropdown" class="is_login">
                                            <span class="flag-icon flag-icon-gb"></span>
                                        English
                    <i class="fa fa-angle-down"></i>
                </a>
                            <ul class="dropdown-menu text-left">
                                                </ul>
    </li>
            </ul>
        </div>
        <div class="g-menu" style="max-height: 590px;">
            <ul class="main-menu menu-generated"><li class=""><a target="" href="index.html">Home <i class="fa fa-angle-down"></i></a><ul class="children-menu menu-dropdown"><li class=" "><a target="" href="/">Home Tour</a></li><li class=" "><a target="" href="/page/space">Home Space</a></li></ul></li><li class=" "><a target="" href="/farmhouse">Farmhouses</a></li><li class=""><a target="" href="/news">News <i class="fa fa-angle-down"></i></a><ul class="children-menu menu-dropdown"><li class=""><a target="" href="/news">News List</a></li><li class=""><a target="" href="/news/morning-in-the-northern-sea">News Detail</a></li></ul></li><li class=""><a target="" href="/contact">Contact</a></li></ul>        </div>
    </div>
</div><?php /**PATH C:\Users\CCS\Desktop\laravel\eFarmHouses\resources\views/layouts/main_header_layout.blade.php ENDPATH**/ ?>